from jupyter_ldap_sync import main

if __name__ == "__main__":
    main()